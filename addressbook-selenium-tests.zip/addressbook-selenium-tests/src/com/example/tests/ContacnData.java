package com.example.tests;

public class ContacnData {
	public String fname;
	public String lname;
	public String address1;
	public String hnumber;
	public String mnumber;
	public String wnumber;
	public String mail1;
	public String mail2;
	public String year;
	public String address2;
	public String phonenumber;

	public ContacnData() {
		
	}
	
	public ContacnData(String fname, String lname, String address1,
			String hnumber, String mnumber, String wnumber, String mail1,
			String mail2, String year, String address2, String phonenumber) {
		this.fname = fname;
		this.lname = lname;
		this.address1 = address1;
		this.hnumber = hnumber;
		this.mnumber = mnumber;
		this.wnumber = wnumber;
		this.mail1 = mail1;
		this.mail2 = mail2;
		this.year = year;
		this.address2 = address2;
		this.phonenumber = phonenumber;
	}
}